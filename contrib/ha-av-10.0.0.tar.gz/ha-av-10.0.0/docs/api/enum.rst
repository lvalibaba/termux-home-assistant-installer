
Enumerations and Flags
======================

.. currentmodule:: av.enum

.. automodule:: av.enum


.. _enums:

Enumerations
------------

.. autoclass:: EnumItem


.. _flags:

Flags
-----

.. autoclass:: EnumFlag

