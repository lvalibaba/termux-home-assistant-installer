Filters
=======

.. automodule:: av.filter.filter

    .. autoclass:: Filter
        :members:


.. automodule:: av.filter.graph

    .. autoclass:: Graph
        :members:


.. automodule:: av.filter.context

    .. autoclass:: FilterContext
        :members:


.. automodule:: av.filter.link

    .. autoclass:: FilterLink
        :members:


.. automodule:: av.filter.pad

    .. autoclass:: FilterPad
        :members:

    .. autoclass:: FilterContextPad
        :members:
