
.. It is all in the other file (that we want at the top-level of the repo).

.. _license:

License
=======

From `LICENSE.txt <https://github.com/PyAV-Org/PyAV/blob/master/LICENSE.txt>`_:

.. literalinclude:: ../../LICENSE.txt
    :language: text
