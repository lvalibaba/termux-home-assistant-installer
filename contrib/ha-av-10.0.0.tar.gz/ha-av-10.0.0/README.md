# ha-av

[![GitHub Test Status][github-tests-badge]][github-tests] \
[![Gitter Chat][gitter-badge]][gitter] [![Documentation][docs-badge]][docs] \
[![Python Package Index][pypi-badge]][pypi] [![Conda Forge][conda-badge]][conda]

ha-av is a fork of [PyAV][pyav] which is used for providing hotfixes for or troubleshooting issues with PyAV in Home Assistant.

[conda-badge]: https://img.shields.io/conda/vn/conda-forge/av.svg?colorB=CCB39A
[conda]: https://anaconda.org/conda-forge/av
[docs-badge]: https://img.shields.io/badge/docs-on%20pyav.org-blue.svg
[docs]: http://pyav.org/docs
[gitter-badge]: https://img.shields.io/gitter/room/nwjs/nw.js.svg?logo=gitter&colorB=cc2b5e
[gitter]: https://gitter.im/PyAV-Org
[pypi-badge]: https://img.shields.io/pypi/v/av.svg?colorB=CCB39A
[pypi]: https://pypi.org/project/av
[github-tests-badge]: https://github.com/PyAV-Org/PyAV/workflows/tests/badge.svg
[github-tests]: https://github.com/PyAV-Org/PyAV/actions?workflow=tests
[github]: https://github.com/PyAV-Org/PyAV
[pyav]: https://pypi.org/project/av/